
import React, { useState, useEffect } from "react";
import {
  Container,
  Typography,
  TextField,
  MenuItem,
  Button,
  Stack,
  Paper,
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { getFilterTickets } from "../api/ticketApi";
import { getAllProjects } from "../api/dropDownApi";
import { getAllUsersByRole } from "../api/userApi";

// Utility: get date X days ago in YYYY-MM-DD
const getDateString = (offset = 0) => {
  const d = new Date();
  d.setDate(d.getDate() + offset);
  return d.toISOString().split("T")[0];
};

// Format date to YYYY-MM-DD HH:mm
const formatDateTime = (isoString) => {
  const date = new Date(isoString);
  return date.toISOString().replace("T", " ").slice(0, 16);
};

export default function Reports() {
  const [formData, setFormData] = useState({
    fromDate: getDateString(-7),
    toDate: getDateString(0),
    employeeName: "",
    projectName: "",
    mainStatus: "",
    ticketNo: "",
  });

  const [filteredData, setFilteredData] = useState([]);
  const [loading, setLoading] = useState(true);

  const statuses = ["Open", "In Process", "Closed", "Working", "Handover"];
  const [projects, setProjects] = useState([]);
  const [employees, setEmployees] = useState([]);

  useEffect(() => {
    const fetchAll = async () => {
      try {
        const [proj, emp] = await Promise.all([
          getAllProjects(),
          getAllUsersByRole("employee"),
        ]);
        setProjects(proj);
        setEmployees(emp);
      } catch (err) {
        console.error("Error loading data:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchAll();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const applyFilters = async () => {
    setLoading(true);
    try {
      const data = await getFilterTickets(formData);
      setFilteredData(data);
    } catch (err) {
      console.error("Error applying filters:", err);
    } finally {
      setLoading(false);
    }
  };

  const headers = ["#", "Date", "Employee", "Project", "Status", "Ticket No"];

  const mapRows = () =>
    filteredData.map((row, i) => [
      i + 1,
      formatDateTime(row.createdTime),
      row.employee,
      row.project,
      row.mainStatus,
      row.ticketNo,
    ]);

  const exportToExcel = () => {
    if (!filteredData.length) return;
    const wsData = [headers, ...mapRows()];
    const worksheet = XLSX.utils.aoa_to_sheet(wsData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Report");
    XLSX.writeFile(
      workbook,
      `Report_${formData.fromDate}_${formData.toDate}.xlsx`
    );
  };

  const exportToPDF = () => {
    if (!filteredData.length) return;
    const doc = new jsPDF({ orientation: "landscape" });
    doc.text(
      `Report (${formData.fromDate} → ${formData.toDate})`,
      14,
      15
    );
    autoTable(doc, {
      startY: 20,
      head: [headers],
      body: mapRows(),
      styles: { fontSize: 8 },
    });
    doc.save(`Report_${formData.fromDate}_${formData.toDate}.pdf`);
  };

  return (
    <Container maxWidth="md" sx={{ mt: 4 }}>
      <Typography variant="h6" fontWeight="bold" gutterBottom>
        Report
      </Typography>
      <Typography color="gray" gutterBottom>
        Home → Report
      </Typography>

      <Paper elevation={1} sx={{ p: 3, mt: 2 }}>
        <Stack spacing={2}>
          <Box display="flex" gap={2}>
            <TextField
              label="From Date"
              type="date"
              name="fromDate"
              value={formData.fromDate}
              onChange={handleChange}
              InputLabelProps={{ shrink: true }}
              fullWidth
            />
            <TextField
              label="To Date"
              type="date"
              name="toDate"
              value={formData.toDate}
              onChange={handleChange}
              InputLabelProps={{ shrink: true }}
              fullWidth
            />
          </Box>

          <TextField
            select
            label="Employee Name"
            name="employeeName"
            value={formData.employeeName}
            onChange={handleChange}
            fullWidth
          >
            <MenuItem value="">- Select -</MenuItem>
            {employees.map((emp) => (
              <MenuItem key={emp._id} value={emp.name}>
                {emp.name}
              </MenuItem>
            ))}
          </TextField>

          <TextField
            select
            label="Project Name"
            name="projectName"
            value={formData.projectName}
            onChange={handleChange}
            fullWidth
          >
            <MenuItem value="">- Select -</MenuItem>
            {projects.map((proj) => (
              <MenuItem key={proj._id} value={proj.project}>
                {proj.project}
              </MenuItem>
            ))}
          </TextField>

          <TextField
            select
            label="Main Status"
            name="mainStatus"
            value={formData.mainStatus}
            onChange={handleChange}
            fullWidth
          >
            <MenuItem value="">- Select -</MenuItem>
            {statuses.map((status) => (
              <MenuItem key={status} value={status}>
                {status}
              </MenuItem>
            ))}
          </TextField>

          <TextField
            label="Ticket No."
            name="ticketNo"
            value={formData.ticketNo}
            onChange={handleChange}
            fullWidth
          />

          <Box display="flex" gap={2}>
            <Button
              onClick={applyFilters}
              variant="contained"
              color="primary"
            >
              Apply
            </Button>
            <Button onClick={exportToExcel} variant="outlined" disabled={loading}>
              Export Excel
            </Button>
            <Button onClick={exportToPDF} variant="outlined" disabled={loading}>
              Export PDF
            </Button>
          </Box>
        </Stack>
      </Paper>

      <TableContainer component={Paper} sx={{ mt: 4 }}>
        <Table size="small">
          <TableHead sx={{ backgroundColor: "#f0f0f0" }}>
            <TableRow>
              {headers.map((h) => (
                <TableCell key={h}>{h}</TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={headers.length} align="center">
                  Loading...
                </TableCell>
              </TableRow>
            ) : filteredData.length > 0 ? (
              filteredData.map((row, i) => (
                <TableRow key={i}>
                  <TableCell>{i + 1}</TableCell>
                  <TableCell>{formatDateTime(row.createdTime)}</TableCell>
                  <TableCell>{row.employee}</TableCell>
                  <TableCell>{row.project}</TableCell>
                  <TableCell>{row.mainStatus}</TableCell>
                  <TableCell>{row.ticketNo}</TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={headers.length} align="center">
                  No records found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </Container>
  );
}